# Plugin Figma — Đoàn Viên Số Design Generator

Plugin sinh **11 màn hình mobile (390px)** của app **Đoàn Viên Số** trực tiếp vào Figma dưới dạng **layer thật (auto-layout, chỉnh sửa được)** — dịch ngược từ design React (`design/src/`) và app Flutter (`doanvien_so/`).

## Cài vào Figma Desktop

1. Mở **Figma Desktop** → vào 1 file design bất kỳ.
2. Menu **☰ → Plugins → Development → Import plugin from manifest…**
3. Chọn file `figma-plugin/manifest.json` (thư mục này).
4. Menu **Plugins → Development → Đoàn Viên Số — Design Generator** để chạy.

## Cách dùng

- **⚡ Tạo toàn bộ màn hình**: sinh 11 frame, xếp lưới 4 cột, có tiêu đề trang.
- **🗑 Xóa các frame đã sinh**: dọn toàn bộ frame có tiền tố `ĐV •` để chạy lại.

## Màn hình được sinh

| # | Màn hình | Vai trò |
|---|----------|---------|
| 01 | Đăng nhập — chọn vai trò | chung |
| 02 | Trang chủ Bí thư (hero 46 ĐV, duyệt sinh hoạt bù, biểu đồ 3 kỳ) | bí thư |
| 03 | Tạo mã QR điểm danh (token KP5-202612-A7F9, geofence) | bí thư |
| 04 | Đoàn viên quét QR (camera mock, GPS, lịch sử) | đoàn viên |
| 05 | Danh bạ & Hồ sơ (46 ĐV, filter 31/12/3) | bí thư |
| 06 | Tổng quan Đoàn Phường (xếp hạng 12 chi đoàn, 485 ĐV) | cán bộ phường |
| 07 | Trang chủ Đoàn viên (buổi sinh hoạt đang diễn ra) | đoàn viên |
| 08 | Lịch hoạt động cá nhân (week strip, 3 tab) | đoàn viên |
| 09 | Thi đua & Khen thưởng (hoạt động, voucher) | đoàn viên |
| 10 | Mạng xã hội Đoàn (feed, sự kiện) | đoàn viên |
| 11 | Tiện ích (profile, shortcut, nhóm chức năng) | bí thư |

## Kỹ thuật

- Design tokens lấy đúng từ `design/tailwind.config.js`: `#161891 / #0E1068 / #EEF0FB / #F5F7FB`, font **Be Vietnam Pro** (nếu máy chưa có font, tự fallback Inter).
- Mock data nhúng đúng từ `design/src/data/mockData.js` (chi đoàn Khu phố 5 — P. Tam Hiệp, TP. Biên Hòa; 46 đoàn viên; token QR; xếp hạng phường…).
- Logo `doantn.png` được nhúng base64 vào `code.js` (dùng cho header + thẻ hồ sơ).
- Icon vẽ bằng vector SVG (lucide-style), hoàn toàn là layer Figma.

## Lưu ý

- Plugin chỉ dùng được trên **Figma Desktop** (import from manifest).
- Mỗi lần "Tạo toàn bộ" sẽ xóa frame cũ có tiền tố `ĐV •` rồi sinh lại — không ảnh hưởng layer khác trong file.
